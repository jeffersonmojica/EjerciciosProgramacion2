package model;

public class SinHojasException extends Exception {
    public SinHojasException(String mensaje) {
        super(mensaje);
    }
}
