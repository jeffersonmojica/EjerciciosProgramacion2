package ui;

public class Runner {
public static void main(String[] args) {
	System.out.println("hola mundo <3");
	System.out.println("soy sergio gomez");
<<<<<<< HEAD
	System.out.println("hola mundo <3");
	JOptionPane.showMessageDialog(null, "Ven la Imagen Cambio.", "Trinisoft",
			JOptionPane.INFORMATION_MESSAGE, new ImageIcon("src/imagenes/impresora.png"))
=======
	System.out.println("soy bayron fuentes");
>>>>>>> dbce6f9031acdd83b16800664debb1447e48ded8
	//prueba sincronizacion git-github-------tarea impresora 200 paginas xxxxxxxxx
}
}
