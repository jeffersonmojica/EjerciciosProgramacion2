module co.edu.uptc.TareaImpresora1 {
	requires java.desktop;
}